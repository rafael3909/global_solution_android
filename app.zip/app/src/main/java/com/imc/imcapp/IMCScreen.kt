
package com.example.imcapp

import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.navigation.NavController

@Composable
fun IMCScreen(nav: NavController) {
    var nome by remember { mutableStateOf("") }
    var peso by remember { mutableStateOf("") }
    var altura by remember { mutableStateOf("") }
    var resultado by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Calculadora IMC", style = MaterialTheme.typography.headlineSmall)

        Spacer(Modifier.height(16.dp))
        TextField(value = nome, onValueChange = { nome = it }, label = { Text("Seu nome") })
        Spacer(Modifier.height(8.dp))
        TextField(value = peso, onValueChange = { peso = it }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), label = { Text("Seu peso") })
        Spacer(Modifier.height(8.dp))
        TextField(value = altura, onValueChange = { altura = it }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), label = { Text("Sua altura") })

        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            val p = peso.toFloatOrNull()
            val a = altura.toFloatOrNull()
            if (p != null && a != null && a > 0) {
                val imc = p / (a * a)
                resultado = "${nome}, seu IMC é %.2f".format(imc)
            }
        }) { Text("Calcular") }

        Spacer(Modifier.height(16.dp))
        Text(resultado)

        Spacer(Modifier.height(16.dp))
        Button(onClick = { nav.navigate("menu") }) { Text("Voltar") }
    }
}

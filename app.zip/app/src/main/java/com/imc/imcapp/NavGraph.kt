
package com.example.imcapp

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable

@Composable
fun AppNavGraph(nav: NavHostController) {
    NavHost(navController = nav, startDestination = "splash") {
        composable("splash") { SplashScreen { nav.navigate("login") } }
        composable("login") { LoginScreen(nav) }
        composable("menu") { MenuScreen(nav) }
        composable("imc") { IMCScreen(nav) }
        composable("team") { TeamScreen(nav) }
    }
}

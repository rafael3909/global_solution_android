
package com.example.imcapp

import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun LoginScreen(nav: NavController) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        TextField(value = user, onValueChange = { user = it }, label = { Text("Usuário") })
        Spacer(Modifier.height(8.dp))
        TextField(value = pass, onValueChange = { pass = it }, label = { Text("Senha") })
        Spacer(Modifier.height(16.dp))

        Button(onClick = {
            if (user == "admin" && pass == "123") {
                nav.navigate("menu")
            } else error = true
        }) { Text("Entrar") }

        if (error) {
            Spacer(Modifier.height(8.dp))
            Text("Usuário inválido", color = MaterialTheme.colorScheme.error)
        }
    }
}
